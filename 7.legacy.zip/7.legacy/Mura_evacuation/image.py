import numpy as np

def bw(immagine):
	for x in range(immagine.shape[0]):
		for y in range(immagine.shape[1]):
			if immagine[x][y] < 128:
				immagine[x][y] = 1 #nero
			else:
				immagine[x][y] = 0 #bianco
	return immagine

def get_points(immagine):
	points = []
	for x in range(immagine.shape[0]):
		for y in range(immagine.shape[1]):
			if immagine[x][y] == 1:
				points.append( (np.array([y,x])).astype(float) )
	return points
