# -*- coding: utf-8 -*-

from __future__ import division
from matplotlib.path import Path
import matplotlib.patches as patches
import sys
import matplotlib.colors as colors
import numpy as np
import math
import matplotlib.pyplot as plt
from igraph import *
import matplotlib.path as mplPath
from shapely.geometry import Polygon
from descartes import PolygonPatch
from shapely.geometry import Point
import PIL
from PIL import Image
from skimage import img_as_ubyte
import random
#import networkx as nx

import segmento as sg
import mean_shift as ms
import retta as rt
import extended_segment as ext
import faccia as fc
import matrice as mtx
import image as im
import disegna as dsg

from itertools import cycle

import cv2
import matplotlib.image as mpimg

from sklearn.cluster import DBSCAN

from scipy.spatial import ConvexHull


def crea_muri(linee):
	'''
trasforma le linee in oggetti di tipo Segmento, e ne ritorna la lista.
	'''
	lista_muri = []
	for muro in linee:
		x1 = float(muro[0])
		y1 = float(muro[1])
		x2 = float(muro[2])
		y2 = float(muro[3])
		lista_muri.append(sg.Segmento(x1,y1,x2,y2))
	return lista_muri
	

def clustering_dbscan_facce(eps, min_samples, X):
	'''
esegue il dbscan clustering sulle facce, prendendo in ingresso eps (massima distanza tra 2 campioni per essere considerati nello stesso neighborhood), min_samples (numero di campioni in un neighborhood per un punto per essere considerato un core point) e X (matrice di affinità locale tra le facce).
	'''
	#af = AffinityPropagation(damping, max_iter, convergence_iter, affinity="precomputed").fit(X)
	af = DBSCAN(eps, min_samples, metric="precomputed").fit(X)
	print("num of clusters = ")
	print len(set(af.labels_))	
	return af.labels_


def flip_lines(linee, altezza):
	'''
flippa le y delle linee, perche' l'origine dei pixel è in alto a sx, invece la voglio in basso a sx
	'''
	for l in linee:
		l[1] = altezza-l[1]
		l[3] = altezza-l[3]
	return linee


def flip_contorni(contours, altezza):
	'''
flippa le y dei punti del contorno
	'''
	for c1 in contours:
		for c2 in c1:
			c2[0][1] = altezza - c2[0][1]
	return contours


def flip_vertici(vertici_porte, altezza):
	'''
flippa le y dei vertici
	'''
	for v in vertici_porte:
		v[1] = altezza - v[1]
	return vertici_porte


def get_estremi(lines):
	'''
ritorna gli estremi delle linee come lista di punti
	'''
	points = []
	for l in lines:
		p1 = np.array([l[0],l[1]])
		p2 = np.array([l[2],l[3]])
		points.extend((p1,p2))
	return points


def uniq(lst):
	'''
elimina i doppioni da una lista
	'''
	last = object()
	for item in lst:
		if item == last:
			continue
		yield item
		last = item


def sort_and_deduplicate(l):
	'''
elimina i doppioni da una lista
	'''
	return list(uniq(sorted(l, reverse=True)))


def algo(p):
	'''
riordina i punti in senso orario
	'''
	return (math.atan2(p[0] - centroid[0], p[1] - centroid[1]) + 2 * math.pi) % (2*math.pi)


def vicini(r,g,b,soglia):
	'''
ritorna True se i valori r,g,b sono tutti e 3 vicini entro una certa soglia, False altrimenti.
	'''
	if (abs(r-g)<soglia) and (abs(r-b)<soglia) and (abs(g-b)<soglia) :
		return True
	return False


def trova_templates(templates, immagine, dim_min, dim_max, threshold):
	'''
trova i templates dentro all'immagine, eseguendo uno scaling da dim_min a dim_max. Il templates è riconosciuto se c'è una somiglianza > threshold. Ritorna i vertici dei rettangoli che delimitano i template trovati.
	''' 
	img3 = immagine.copy()
	vertici = []
	for template in templates:
		for basewidth in xrange(dim_min, dim_max):
			#img = img_rgb.copy()
			wpercent = (basewidth / float(template.size[0]))
			hsize = int((float(template.size[1]) * float(wpercent)))
			temp = template.resize((basewidth, hsize), PIL.Image.ANTIALIAS)
			temp = img_as_ubyte(temp)
			if(len(temp.shape)>2):
				temp = cv2.cvtColor(temp, cv2.COLOR_RGB2GRAY)
			w, h = temp.shape[::-1]
			res = cv2.matchTemplate(img_gray,temp,cv2.TM_CCOEFF_NORMED)
			loc = np.where( res >= threshold)
			for pt in zip(*loc[::-1]):
				cv2.rectangle(img3, pt, (pt[0] + w, pt[1] + h), (255,0,0), 2)
				vertici.append([float(pt[0]),float(pt[1])])
				vertici.append([float(pt[0]),float(pt[1]+h)])
				vertici.append([float(pt[0]+w),float(pt[1]+h)])
				vertici.append([float(pt[0]+w),float(pt[1])])
				#print(pt[0], pt[1], pt[0]+w, pt[1]+h)
	plt.imshow(cv2.cvtColor(img3,cv2.COLOR_BGR2RGB))
	plt.show()
	vertici = flip_vertici(vertici, image.shape[0]-1)
	return vertici


def sostituisci_porte(templates, templates_muri, immagine, dim_min, dim_max, threshold):
	'''
cerca i template delle porte e li sostituisce con i corrispondenti template dei muri, scalati della stessa quantità. Ritorna l'immagine così modificata.
	'''
	img3 = immagine.copy()
	for index,template in enumerate(templates):
		for basewidth in xrange(dim_min, dim_max):
			#img = img_rgb.copy()
			wpercent = (basewidth / float(template.size[0]))
			hsize = int((float(template.size[1]) * float(wpercent)))
			temp = template.resize((basewidth, hsize), PIL.Image.ANTIALIAS)
			temp = img_as_ubyte(temp)
			if(len(temp.shape)>2):
				temp = cv2.cvtColor(temp, cv2.COLOR_RGB2GRAY)
			w, h = temp.shape[::-1]
			res = cv2.matchTemplate(img_gray,temp,cv2.TM_CCOEFF_NORMED)
			loc = np.where( res >= threshold)
			for pt in zip(*loc[::-1]):
				resized = cv2.resize(templates_muri[index], (w,h))
				img3[pt[1]:pt[1]+resized.shape[0], pt[0]:pt[0]+resized.shape[1]] = resized
	plt.imshow(cv2.cvtColor(img3,cv2.COLOR_BGR2RGB))
	plt.show()
	return img3


def crea_poligoni(vertici):
	'''
dati i vertici dei templates trovati, ogni 4 vertici crea un poligono
	'''
	i = 0
	poligoni = []
	while(i < len(vertici)):
		poligono = Polygon(vertici[i:i+4])	
		poligoni.append(poligono)
		i += 4
	return poligoni


def crea_facce_poligoni(facce, contorno):
	
	return (facce_poligoni, indici)




#----------------------MAIN-----------------------------------------------------------------

file_name = '/home/matteo/Desktop/piani_evacuazione/eva.png'
image = cv2.imread(file_name)

#distanza massima in pixel per cui 2 segmenti con stesso cluster angolare sono considerati appartenenti anche allo stesso cluster spaziale 
min_lateral_separation = 7


#----------------TROVO PORTE--------------------------------------------------------------

img_rgb = cv2.imread(file_name)
img_gray = cv2.cvtColor(img_rgb, cv2.COLOR_BGR2GRAY)
templates_porte = []
templates_muri = []

#setto i template delle porte da cercare nell'immagine, e i template dei muri con cui sostituire quelli delle porte, per migliorare il clustering (se al posto della porta metto un muro è più facile che le 2 stanze vengano viste come diverse).
template1 = Image.open('/home/matteo/Desktop/piani_evacuazione/door.png')
template2 = Image.open('/home/matteo/Desktop/piani_evacuazione/door2.png')
template3 = Image.open('/home/matteo/Desktop/piani_evacuazione/door3.png')
template4 = Image.open('/home/matteo/Desktop/piani_evacuazione/door4.png')
template5 = Image.open('/home/matteo/Desktop/piani_evacuazione/door_f.png')
template6 = Image.open('/home/matteo/Desktop/piani_evacuazione/door2_f.png')
template7 = Image.open('/home/matteo/Desktop/piani_evacuazione/door3_f.png')
template8 = Image.open('/home/matteo/Desktop/piani_evacuazione/door4_f.png')
template9 = cv2.imread('/home/matteo/Desktop/piani_evacuazione/wall.png')
template10 = cv2.imread('/home/matteo/Desktop/piani_evacuazione/wall2.png')
template11 = cv2.imread('/home/matteo/Desktop/piani_evacuazione/wall3.png')
template12 = cv2.imread('/home/matteo/Desktop/piani_evacuazione/wall4.png')
template13 = cv2.imread('/home/matteo/Desktop/piani_evacuazione/wall_f.png')
template14 = cv2.imread('/home/matteo/Desktop/piani_evacuazione/wall2_f.png')
template15 = cv2.imread('/home/matteo/Desktop/piani_evacuazione/wall3_f.png')
template16 = cv2.imread('/home/matteo/Desktop/piani_evacuazione/wall4_f.png')
'''
template21 = Image.open('/home/matteo/Desktop/piani_evacuazione/door17.png')
template22 = Image.open('/home/matteo/Desktop/piani_evacuazione/door18.png')
template23 = Image.open('/home/matteo/Desktop/piani_evacuazione/door19.png')
template24 = Image.open('/home/matteo/Desktop/piani_evacuazione/door20.png')
template25 = cv2.imread('/home/matteo/Desktop/piani_evacuazione/wall17.png')
template26 = cv2.imread('/home/matteo/Desktop/piani_evacuazione/wall18.png')
template27 = cv2.imread('/home/matteo/Desktop/piani_evacuazione/wall19.png')
template28 = cv2.imread('/home/matteo/Desktop/piani_evacuazione/wall20.png')
'''
templates_porte.extend((template1,template2,template3,template4,template5,template6,template7,template8))
templates_muri.extend((template9,template10,template11,template12,template13,template14,template15,template16))
img2 = img_rgb.copy()
vertici_porte = trova_templates(templates_porte, img_rgb, 20, 30, 0.7)
img_con_porte = sostituisci_porte(templates_porte, templates_muri, img2, 20, 30, 0.7)
#per ogni contorno delle porte creo un poligono
porte = crea_poligoni(vertici_porte)


#-------------TROVO ESTINTORI-----------------------------------------------------------

template25 = Image.open('/home/matteo/Desktop/piani_evacuazione/estintore.png')
template26 = Image.open('/home/matteo/Desktop/piani_evacuazione/estintore2.png')
template27 = Image.open('/home/matteo/Desktop/piani_evacuazione/estintore3.png')
template28 = Image.open('/home/matteo/Desktop/piani_evacuazione/estintore4.png')
template30 = Image.open('/home/matteo/Desktop/piani_evacuazione/estintore5.png')
'''
template25 = Image.open('/home/matteo/Desktop/piani_evacuazione/estintore6.png')
template26 = Image.open('/home/matteo/Desktop/piani_evacuazione/estintore7.png')
template27 = Image.open('/home/matteo/Desktop/piani_evacuazione/estintore8.png')
'''
img3 = img_rgb.copy()
templates_estintori = []
templates_estintori.extend((template25,template26,template27,template28))
vertici_estintori = trova_templates(templates_estintori, img_rgb, 11, 14, 0.9)
#per ogni contorno delle porte creo un poligono
estintori = crea_poligoni(vertici_estintori)


#-------------------TROVO IDRANTI-----------------------------------------------------------

img3 = img_rgb.copy()
template29 = Image.open('/home/matteo/Desktop/piani_evacuazione/idrante.png')
'''
template29 = Image.open('/home/matteo/Desktop/piani_evacuazione/idrante2.png')
template30 = Image.open('/home/matteo/Desktop/piani_evacuazione/idrante3.png')
template31 = Image.open('/home/matteo/Desktop/piani_evacuazione/idrante4.png')
'''
templates_idranti = []
templates_idranti.append(template29)
#templates_idranti.extend((template29,template30,template31))
vertici_idranti = trova_templates(templates_idranti, img_rgb, 17, 20, 0.8)
#per ogni contorno delle porte creo un poligono
idranti = crea_poligoni(vertici_idranti)


#-------------------TROVO KIT----------------------------------------------------------

img3 = img_rgb.copy()
template31 = Image.open('/home/matteo/Desktop/piani_evacuazione/kit.png')
templates_kit = []
templates_kit.append(template31)
vertici_kit = trova_templates(templates_kit, img_rgb, 12, 16, 0.8)
#per ogni contorno delle porte creo un poligono
kits = crea_poligoni(vertici_kit)


#---------------CONTORNO ESTERNO-------------------------------------------------------

#creo i contorni: canny sull'immagine iniziale, hough, plotto le hough lines su un'immagine bianca, applico la funzione cv2.findContours con retrieval_mode = external per trovare i contorni esterni. Se i contorni esterni sono più di 1, devo riapplicare la hough aumentando la minLineLenght, in modo da rendere unico il contorno esterno.
edges_canny = cv2.Canny(image,90,100,apertureSize = 5)
t=1
m=20
hough_contorni = cv2.HoughLinesP(edges_canny,1,np.pi/180,threshold=t,minLineLength=1,maxLineGap=m)
img4 = cv2.imread(file_name,0)
ret,bianca = cv2.threshold(img4,255,255,cv2.THRESH_BINARY_INV)
bianca2 = bianca.copy()
for x1,y1,x2,y2 in hough_contorni[0]:
	cv2.line(bianca2,(x1,y1),(x2,y2),(0,0,0),2)
ret,bianca2 = cv2.threshold(bianca2,253,255,cv2.THRESH_BINARY_INV)
contours, hierarchy = cv2.findContours(bianca2.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
while(len(contours)!=1): #se il contorno esterno trovato non è unico
	t+=1
	#m+=1
	hough_contorni = cv2.HoughLinesP(edges_canny,1,np.pi/180,threshold=t,minLineLength=1,maxLineGap=m)
	bianca2 = bianca.copy()
	for x1,y1,x2,y2 in hough_contorni[0]:
		cv2.line(bianca2,(x1,y1),(x2,y2),(0,0,0),2)
	ret,bianca2 = cv2.threshold(bianca2,253,255,cv2.THRESH_BINARY_INV)
	contours, hierarchy = cv2.findContours(bianca2.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

dsg.disegna_hough(edges_canny, hough_contorni)

contours = flip_contorni(contours, image.shape[0]-1)


#--------------ELIMINO PORTE E ESTINTORI E IDRANTI---------------------------------------

b,g,r = cv2.split(img_con_porte)
#elimino le porte
'''
for p in porte:
	bounds = p.bounds #(minx,miny,maxx,maxy)
	for i in xrange(int(bounds[0]),int(bounds[2])):
		for j in xrange(int(bounds[1]),int(bounds[3])):
			r[image.shape[0]-j,i]=255
			g[image.shape[0]-j,i]=255
			b[image.shape[0]-j,i]=255
'''
img = cv2.merge((b,g,r))

#elimino gli estintori
b,g,r = cv2.split(img)
for e in estintori:
	bounds = e.bounds #(minx,miny,maxx,maxy)
	for i in xrange(int(bounds[0]),int(bounds[2])):
		for j in xrange(int(bounds[1]),int(bounds[3])):
			r[image.shape[0]-j,i]=255
			g[image.shape[0]-j,i]=255
			b[image.shape[0]-j,i]=255
img = cv2.merge((b,g,r))

#elimino gli idranti
b,g,r = cv2.split(img)
for i in idranti:
	bounds = i.bounds #(minx,miny,maxx,maxy)
	for i in xrange(int(bounds[0]),int(bounds[2])):
		for j in xrange(int(bounds[1]),int(bounds[3])):
			r[image.shape[0]-j,i]=255
			g[image.shape[0]-j,i]=255
			b[image.shape[0]-j,i]=255
img = cv2.merge((b,g,r))

#elimino i kit di pronto soccorso
b,g,r = cv2.split(img)
for k in kits:
	bounds = k.bounds #(minx,miny,maxx,maxy)
	for i in xrange(int(bounds[0]),int(bounds[2])):
		for j in xrange(int(bounds[1]),int(bounds[3])):
			r[image.shape[0]-j,i]=255
			g[image.shape[0]-j,i]=255
			b[image.shape[0]-j,i]=255
img = cv2.merge((b,g,r))
plt.imshow(cv2.cvtColor(img,cv2.COLOR_BGR2RGB))
plt.show()

	
'''
#--------------------ELIMINO TESTO-----------------

b,g,r = cv2.split(img)

gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)  # grayscale
#_, thresh = cv2.threshold(gray, 200, 255, cv2.THRESH_BINARY_INV)  # threshold
_, thresh = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY_INV)
#kernel = cv2.getStructuringElement(cv2.MORPH_CROSS, (3, 3))
kernel = cv2.getStructuringElement(cv2.MORPH_CROSS, (3, 3))
dilated = cv2.dilate(thresh, kernel, iterations = 2)  # dilate
contours_text, hierarchy = cv2.findContours(dilated, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)  # get contours


#elimino il testo
#img = image.copy()
#c_copy = contours [:]
#contours_flipped = flip_contorni(c_copy, image.shape[0]-1)
# for each contour found, draw a rectangle around it on original image
for contour in contours_text:
	vertici = []
	for c2 in contour:
		vertici.append([float(c2[0][0]),float(c2[0][1])])
	# get rectangle bounding contour
	[x, y, w, h] = cv2.boundingRect(contour)
	# discard areas that are too large
	if (h > 40) and (w > 40):
		continue
	# discard areas that are too small
	#if h < 10 or w < 10:
	#	continue
	# draw rectangle around contour on original image
	cv2.rectangle(img, (x, y), (x+w, y+h), (255, 0, 255), 2)
	contorno = Polygon(vertici)
	for i in xrange(x-1,x+w+1):
		for j in xrange(y-1,y+h+1):
			p = Point(i,j)
			if p.within(contorno):
				r[j,i]=255
				g[j,i]=255
				b[j,i]=255
	

img = cv2.merge((b,g,r))
plt.imshow(cv2.cvtColor(img,cv2.COLOR_BGR2RGB))
plt.show()
'''
b,g,r = cv2.split(img)
w, h, channels = img.shape


#------------------ELIMINO I COLORI----------------------------------------------

#trasformo grigio in nero, poiche' i muri sono grigi. Se non lo faccio, quando trasformo i colori in bianco (frecce verdi, rimasugli di estintori idranti ecc) diventerebbero bianchi anche i muri.
soglia=10
for i in range(w):
    for j in range(h):
	if(r[i, j] < 160 and g[i, j] < 160 and b[i, j] < 160):
		if(vicini(int(r[i,j]),int(g[i,j]),int(b[i,j]),soglia)):
			r[i,j]=0
			g[i,j]=0
			b[i,j]=0	

img = cv2.merge((b,g,r))
plt.imshow(cv2.cvtColor(img,cv2.COLOR_BGR2RGB))
plt.show()
#trasformo in scala di grigi
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
#tutto cio' che non e' propriamente nero lo metto bianco (elimino quindi tutti i colori, frecce verdi ecc)
ret,thresh = cv2.threshold(gray,10,255,cv2.THRESH_BINARY_INV)
plt.imshow(thresh,cmap='Greys')
plt.show()


#-------------------EROSION---------------------------------------------------------

kernel = np.ones((3,3),np.uint8)
erosion = cv2.erode(thresh,kernel,iterations = 1)
plt.imshow(erosion,cmap='Greys')
plt.show()

edges_canny = cv2.Canny(erosion,90,100,apertureSize = 5)
dsg.disegna_canny(edges_canny)
lines_hough = cv2.HoughLinesP(edges_canny,1,np.pi/180,threshold=8,minLineLength=6,maxLineGap=3)
dsg.disegna_hough(erosion,lines_hough)

lines = flip_lines(lines_hough[0], img.shape[0]-1)


#------------CREO LISTA_MURI--------------------------------------------------------

lista_muri = crea_muri(lines)

'''
for s in segmenti:
	if sg.lunghezza(s.x1,s.y1,s.x2,s.y2) >= 2:
		lista_muri.append(s)
'''

for muro in lista_muri:
	d = sg.inclinazione_radianti(muro.x1, muro.y1, muro.x2, muro.y2)
	if (d < -1.3):
		d += math.pi
	muro.set_direction(d)

#dsg.disegna(lista_muri)

#creo lista delle inclinazioni degli edges
directions = []
for muro in lista_muri:
	directions.append(muro.direction)


#-------------------MEAN SHIFT PER TROVARE CLUSTER ANGOLARI---------------------------------------

h = 0.023
offset_minimo = 0.00001
#creo i cluster centers tramite mean shift
cluster_centers = ms.mean_shift(h, offset_minimo, directions)


#ci sono dei cluster angolari che sono causati da pochi e piccoli line_segments, che sono solamente rumore. Questi cluster li elimino dalla lista cluster_centers ed elimino anche i rispettivi segmenti dalla lista_muri.
num_min = 3
lunghezza_min = 3
indici = ms.indici_da_eliminare(num_min, lunghezza_min, cluster_centers, lista_muri)


#ora che ho gli indici di clusters angolari e di muri da eliminare, elimino da lista_muri e cluster_centers, partendo dagli indici piu alti
for i in sorted(indici, reverse=True):
	del lista_muri[i]
	del cluster_centers[i]


#ci son dei cluster che si somigliano ma non combaciano per una differenza infinitesima, e non ho trovato parametri del mean shift che rendano il clustering piu' accurato di cosi', quindi faccio una media normalissima, tanto la differenza e' insignificante.
unito = ms.unisci_cluster_simili(cluster_centers)
while(unito):
	unito = ms.unisci_cluster_simili(cluster_centers)


#assegno i cluster ai muri di lista_muri
lista_muri = sg.assegna_cluster_angolare(lista_muri, cluster_centers)


#creo lista di cluster_angolari
cluster_angolari = []
for muro in lista_muri:
	cluster_angolari.append(muro.cluster_angolare)


#---------------CLUSTER SPAZIALI--------------------------------------------------------------------

#setto i cluster spaziali a tutti i muri di lista_muri
lista_muri = sg.set_cluster_spaziali(min_lateral_separation, lista_muri)

#sg.disegna_cluster_angolari(cluster_centers, lista_muri, cluster_angolari)

#creo lista di cluster spaziali
cluster_spaziali = []
for muro in lista_muri:
	cluster_spaziali.append(muro.cluster_spaziale)

sg.disegna_cluster_spaziali(cluster_spaziali, lista_muri)

[x, y, w, h] = cv2.boundingRect(contours[0])


#------------SETTO XMIN YMIN XMAX YMAX DI LISTA_MURI--------------------------------------------

estremi = sg.trova_estremi(lista_muri)
xmin = min(x,estremi[0])
xmax = max(x+w,estremi[1])
ymin = min(y,estremi[2])
ymax = max(y+h,estremi[3])
#print(x,estremi[0],x+w,estremi[1],y,estremi[2],y+h,estremi[3])
#print(xmin,ymin,xmax,ymax)
offset = 20
xmin -= offset
xmax += offset
ymin -= offset
ymax += offset


#-------------------CREO EXTENDED_LINES---------------------------------------------------------

extended_lines = rt.crea_extended_lines(cluster_spaziali, lista_muri, xmin, ymin)

#extended_lines hanno punto, cluster_angolare e cluster_spaziale, per disegnarle pero' mi servono 2 punti. Creo lista di segmenti
extended_segments = ext.crea_extended_segments(xmin,xmax,ymin,ymax, extended_lines)

#disegno le extended_lines in nero e la mappa in rosso
ext.disegna_extended_segments(extended_segments, lista_muri)


#-------------CREO GLI EDGES TRAMITE INTERSEZIONI TRA EXTENDED_LINES-------------------------------

punti = []
edges = sg.crea_edges(extended_segments)

#sg.disegna_segmenti(edges)
#sg.disegna_cluster_spaziali(cluster_spaziali, edges)


#----------------------SETTO PESI DEGLI EDGES------------------------------------------------------

edges = sg.set_peso_edges(edges, lista_muri)

#sg.disegna_pesanti(edges, peso_min)


#----------------CREO LE FACCE DAGLI EDGES----------------------------------------------------------

print("creando le facce")
facce = fc.crea_facce(edges)
print("facce create")

#print(len(facce))

#fc.disegna_facce(facce)


#----------------CREO POLIGONO CONTORNO ED ELIMINO FACCE FUORI----------------------------------------------

#creo poligono del contorno
vertici = []
for c1 in contours:
	for c2 in c1:
		vertici.append([float(c2[0][0]),float(c2[0][1])])
dsg.disegna_contorno(vertici,xmin,ymin,xmax,ymax)

contorno = Polygon(vertici)

#creo i poligoni delle facce e salvo gli indici di quelle fuori dal contorno, che verranno poi cancellate.
indici = []
facce_poligoni = []
for index,f in enumerate(facce):
	punti = []
	for b in f.bordi:
		punti.append([float(b.x1),float(b.y1)])
		punti.append([float(b.x2),float(b.y2)])
	#elimino i punti ripetuti
	punti = sort_and_deduplicate(punti)
	x = [p[0] for p in punti]
	y = [p[1] for p in punti]
	centroid = (sum(x) / len(punti), sum(y) / len(punti))
	#ordino i punti in senso orario	
	punti.sort(key=algo)
	faccia = Polygon(punti)
	#se non interseca il contorno è fuori completamente.
	if faccia.intersects(contorno)==False:
		indici.append(index)
		f.set_out(True)
	#se lo interseca ma sporge per più della metà.
	if (faccia.intersects(contorno))and(faccia.intersection(contorno).area < faccia.area/2): #e' fuori piu' della meta'
		indici.append(index)
		f.set_out(True)
	#se lo interseca ma sporge per meno della metà.
	if (faccia.intersects(contorno))and(faccia.intersection(contorno).area >= faccia.area/2):
		f.set_out(False)
		facce_poligoni.append(faccia)

#elimino le facce fuori.
for i in sorted(indici, reverse=True):
	del facce[i]


#------------------CREO LE MATRICI L, D, D^-1, ED M = D^-1 * L---------------------------------------

sigma = 0.1
val = 0
matrice_l = mtx.crea_matrice_l(facce, sigma, val)

matrice_d = mtx.crea_matrice_d(matrice_l)

matrice_d_inv = matrice_d.getI()

matrice_m = matrice_d_inv.dot(matrice_l)
matrice_m = mtx.simmetrizza(matrice_m)

X = 1-matrice_m


#----------------DBSCAN PER TROVARE FACCE NELLA STESSA STANZA-----------------------------------------

labels = []
eps = 0.85
min_samples = 1
labels = clustering_dbscan_facce(eps, min_samples, X)

plt.show()


dsg.disegna_dbscan(labels, facce, facce_poligoni, xmin, ymin, xmax, ymax, edges, contours, False)


plt.show()


#---------------TROVO LE FACCE COLLEGATE DA UNA PORTA--------------------------------

labels_collegate = [] #andrà a contenere le coppie di labels collegate da una porta.
#per ogni porta vado a vedere quali labels la intersecano.
for porta in porte:
	labels_porta = []
	for l in set(labels):
		for index,label in enumerate(labels):
			if(l==label):
				faccia = facce_poligoni[index]
				#se la faccia interseca la porta e la sua label non è già presenta in labels_porta, la aggiungo.
				if(faccia.intersects(porta)):
					if not (l in labels_porta):
						labels_porta.append(l)
						break
	#se ho trovato 2 labels che intersecano la porta, le aggiungo a labels_collegate.
	if (len(labels_porta)==2) and not (labels_porta in labels_collegate):	
		labels_collegate.append(labels_porta)
	#se ne ho trovate più di 2, le aggiungo a 2 a 2.
	if (len(labels_porta)>2): #se piu di 2 mi da problemi nell'add_edges_from
		for index,a in enumerate(labels_porta):
			for b in labels_porta[index+1:]:
				tmp = []
				tmp.extend((a,b))
				if not (tmp in labels_collegate):
					labels_collegate.append(tmp)	


#-------------------TROVO LE STANZE CON ESTINTORE--------------

stanze_con_estintore = []
for estintore in estintori:
	labels_estintore = []
	for l in set(labels):
		for index,label in enumerate(labels):
			if(l==label):
				faccia = facce_poligoni[index]
				if(faccia.intersects(estintore)):
					if not (l in labels_estintore):
						labels_estintore.append(l)
						break
	#se c'è più di una stanza che interseca l'estintore, prendo solo quella che la interseca maggiormente.	
	if (len(labels_estintore)>1):
		max_intersezione = 0	
		for l in labels_estintore:
			for index,label in enumerate(labels):
				if(l==label):
					intersezione = facce_poligoni[index].intersection(estintore).area
					if intersezione>max_intersezione:
						label_max = label
		labels_estintore = []
		labels_estintore.append(label_max)
	#se non è già stata aggiunta all'elenco di stanze con estintore, la aggiungo.
	if not (labels_estintore in stanze_con_estintore):
		stanze_con_estintore.append(labels_estintore)
print("le stanze con estintore sono: ")
print(stanze_con_estintore)
print("\n")


#-------------------TROVO LE STANZE CON IDRANTE--------------

stanze_con_idrante = []
for idrante in idranti:
	labels_idrante = []
	for l in set(labels):
		for index,label in enumerate(labels):
			if(l==label):
				faccia = facce_poligoni[index]
				if(faccia.intersects(idrante)):
					if not (l in labels_idrante):
						labels_idrante.append(l)
						break
	if (len(labels_idrante)>1):
		max_intersezione = 0	
		for l in labels_idrante:
			for index,label in enumerate(labels):
				if(l==label):
					intersezione = facce_poligoni[index].intersection(idrante).area
					if intersezione>max_intersezione:
						label_max = label
		labels_idrante = []
		labels_idrante.append(label_max)
	if not (labels_idrante in stanze_con_idrante):
		stanze_con_idrante.append(labels_idrante)
print("le stanze con idrante sono: ")
print(stanze_con_idrante)
print("\n")


#----------------------------------GRAFO---------------------------------------------------------------

'''
G=nx.Graph()
for l in set(labels):
	G.add_node(l)

G.add_edges_from(labels_collegate)

pos=nx.spring_layout(G)
nx.draw_networkx_nodes(G,pos)
nx.draw_networkx_edges(G,pos)
nx.draw_networkx_labels(G,pos)
plt.show()
'''

G = Graph()
for l in set(labels):
	G.add_vertices(1)
	G.vs[len(G.vs)-1]["label"] = l
	if l in stanze_con_estintore:
		#G.vs[len(G.vs)-1]["label"] = str(l)+" estintore "
		G.vs[len(G.vs)-1]["estintore"]=True
	else:
		G.vs[len(G.vs)-1]["estintore"]=False
#G.add_vertices(1)
#G.vs[len(G.vs)-1]["label"] = str("estintore")

G.add_edges(labels_collegate)
#for index,v in enumerate(G.vs):
#	if v["estintore"]:
#		G.add_edges((index,len(G.vs)-1))
color_dict = {True: "red", False: "white"}
G.vs["color"] = [color_dict[estintore] for estintore in G.vs["estintore"]]
layout = G.layout("kk")
plot(G, layout = layout)


				
