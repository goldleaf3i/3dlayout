# -*- coding: utf-8 -*-

from __future__ import division
from matplotlib.path import Path
import matplotlib.patches as patches
import sys
import matplotlib.colors as colors
import numpy as np
import math
import matplotlib.pyplot as plt
from igraph import *
import matplotlib.path as mplPath
from shapely.geometry import Polygon
from descartes import PolygonPatch
from shapely.geometry import Point
import random

import segmento as sg
import mean_shift as ms
import retta as rt
import extended_segment as ext
import faccia as fc
import matrice as mtx
import image as im
import disegna as dsg

from itertools import cycle

import cv2
import matplotlib.image as mpimg

from sklearn.cluster import DBSCAN

from scipy.spatial import ConvexHull


def crea_muri(linee):
	'''
trasforma le linee in oggetti di tipo Segmento, e ne ritorna la lista.
	'''
	lista_muri = []
	for muro in linee:
		x1 = float(muro[0])
		y1 = float(muro[1])
		x2 = float(muro[2])
		y2 = float(muro[3])
		lista_muri.append(sg.Segmento(x1,y1,x2,y2))
		#vedo se il muro e' piu corto di una soglia, se e' cosi' allora non lo salvo
		#if(sg.lunghezza(x1,y1,x2,y2) >= lunghezza_minima):
		#	lista_muri.append(sg.Segmento(x1,y1,x2,y2))
	return lista_muri
	

def clustering_dbscan_facce(eps, min_samples, X):
	'''
esegue il dbscan clustering sulle facce, prendendo in ingresso eps (massima distanza tra 2 campioni per essere considerati nello stesso neighborhood), min_samples (numero di campioni in un neighborhood per un punto per essere considerato un core point) e X (matrice di affinità locale tra le facce).
	'''
	#af = AffinityPropagation(damping, max_iter, convergence_iter, affinity="precomputed").fit(X)
	af = DBSCAN(eps, min_samples, metric="precomputed").fit(X)
	print("num of clusters = ")
	print len(set(af.labels_))	
	return af.labels_


def flip_lines(linee, altezza):
	'''
flippa le y delle linee, perche' l'origine dei pixel è in alto a sx, invece la voglio in basso a sx
	'''
	for l in linee:
		l[1] = altezza-l[1]
		l[3] = altezza-l[3]
	return linee


def flip_contorni(contours, altezza):
	'''
flippa le y dei punti del contorno
	'''
	for c1 in contours:
		for c2 in c1:
			c2[0][1] = altezza - c2[0][1]
	return contours


def get_estremi(lines):
	'''
ritorna gli estremi delle linee come lista di punti
	'''
	points = []
	for l in lines:
		p1 = np.array([l[0],l[1]])
		p2 = np.array([l[2],l[3]])
		points.extend((p1,p2))
	return points


def uniq(lst):
	'''
elimina i doppioni da una lista
	'''
	last = object()
	for item in lst:
		if item == last:
			continue
		yield item
		last = item

def sort_and_deduplicate(l):
	'''
elimina i doppioni da una lista
	'''
	return list(uniq(sorted(l, reverse=True)))


def algo(p):
	'''
riordina i punti in senso orario
	'''
	return (math.atan2(p[0] - centroid[0], p[1] - centroid[1]) + 2 * math.pi) % (2*math.pi)


def isolato(immagine,riga,col):
	'''
ritorna True se il pixel di coordinate [riga][col] (che ha valore True) non ha attorno un altro pixel con valore True, False altrimenti.
	'''
	for r in xrange(max(0,riga-1),min(immagine.shape[0],riga+2)):
		for c in xrange(max(0,col-1),min(immagine.shape[1],col+2)):
			if (immagine[r][c]==True) and not (r==riga and c==col):
				return False
	return True


def flip_vertici(vertici, altezza):
	'''
flippo le y dei vertici
	'''
	for v in vertici:
		v[1] = altezza - v[1]
	return vertici


#--------------------MAIN-------------------------------------------------------------

min_lateral_separation = 6
image = '/home/matteo/Desktop/input_mura/e_doors.png'
img = cv2.imread(image)

ret,thresh1 = cv2.threshold(img,127,255,cv2.THRESH_BINARY)
edges_canny = cv2.Canny(thresh1,90,100,apertureSize = 5)
dsg.disegna_canny(edges_canny)
#lines_hough = cv2.HoughLinesP(edges_canny,1,np.pi/180,threshold=20,minLineLength=7,maxLineGap=10) #usato per b d e
#lines_hough = cv2.HoughLinesP(edges_canny,1,np.pi/180,threshold=15,minLineLength=7,maxLineGap=10) #usato per c
lines_hough = cv2.HoughLinesP(edges_canny,1,np.pi/180,threshold=20,minLineLength=5,maxLineGap=10) #22 10 10 per f

dsg.disegna_hough(img,lines_hough)

lines = flip_lines(lines_hough[0], img.shape[0]-1)


#---------------CONTORNO ESTERNO-------------------------------------------------------

#creo i contorni: canny sull'immagine iniziale, hough, plotto le hough lines su un'immagine bianca, applico la funzione cv2.findContours con retrieval_mode = external per trovare i contorni esterni. Se i contorni esterni sono più di 1, devo riapplicare la hough aumentando la minLineLenght, in modo da rendere unico il contorno esterno.
edges_canny = cv2.Canny(img,90,100,apertureSize = 5)
t=1
m=25
#hough_contorni = cv2.HoughLinesP(edges_canny,1,np.pi/180,threshold=t,minLineLength=1,maxLineGap=m) #va bene con tutti, anche con f
hough_contorni = cv2.HoughLinesP(edges_canny,1,np.pi/180,threshold=t,minLineLength=1,maxLineGap=m)
bianca = cv2.imread(image,0)
ret,thresh = cv2.threshold(bianca,255,255,cv2.THRESH_BINARY_INV)
thresh2 = thresh.copy()
for x1,y1,x2,y2 in hough_contorni[0]:
	#cv2.line(bianca2,(x1,y1),(x2,y2),(0,255,0),2)
	cv2.line(thresh2,(x1,y1),(x2,y2),(0,0,0),2)
ret,thresh2 = cv2.threshold(thresh2,253,255,cv2.THRESH_BINARY_INV)
contours, hierarchy = cv2.findContours(thresh2.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
while(len(contours)!=1): #se il contorno esterno trovato non è unico
	t+=1
	#m+=1
	hough_contorni = cv2.HoughLinesP(edges_canny,1,np.pi/180,threshold=t,minLineLength=1,maxLineGap=m)
	thresh2 = thresh.copy()
	for x1,y1,x2,y2 in hough_contorni[0]:
		cv2.line(thresh2,(x1,y1),(x2,y2),(0,0,0),2)
	ret,thresh2 = cv2.threshold(thresh2,253,255,cv2.THRESH_BINARY_INV)
	contours, hierarchy = cv2.findContours(thresh2.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

contours = flip_contorni(contours, img.shape[0]-1)


#------------CREO LISTA_MURI---------------------------------------------------

lista_muri = crea_muri(lines)

'''
for s in segmenti:
	if sg.lunghezza(s.x1,s.y1,s.x2,s.y2) >= 2:
		lista_muri.append(s)
'''

for muro in lista_muri:
	d = sg.inclinazione_radianti(muro.x1, muro.y1, muro.x2, muro.y2)
	if (d < -1.3):
		d += math.pi
	muro.set_direction(d)

#disegna(lista_muri)

#creo lista delle inclinazioni degli edges
directions = []
for muro in lista_muri:
	directions.append(muro.direction)


#-------------------MEAN SHIFT PER TROVARE CLUSTER ANGOLARI---------------------------------------

h = 0.023
offset_minimo = 0.00001
#creo i cluster centers tramite mean shift
cluster_centers = ms.mean_shift(h, offset_minimo, directions)


#ci sono dei cluster angolari che sono causati da pochi e piccoli line_segments, che sono solamente rumore. Questi cluster li elimino dalla lista cluster_centers ed elimino anche i rispettivi segmenti dalla lista_muri.
num_min = 3
lunghezza_min = 3
indici = ms.indici_da_eliminare(num_min, lunghezza_min, cluster_centers, lista_muri)


#ora che ho gli indici di clusters angolari e di muri da eliminare, elimino da lista_muri e cluster_centers, partendo dagli indici piu alti
for i in sorted(indici, reverse=True):
	del lista_muri[i]
	del cluster_centers[i]


#ci son dei cluster che si somigliano ma non combaciano per una differenza infinitesima, e non ho trovato parametri del mean shift che rendano il clustering piu' accurato di cosi', quindi faccio una media normalissima, tanto la differenza e' insignificante.
unito = ms.unisci_cluster_simili(cluster_centers)
while(unito):
	unito = ms.unisci_cluster_simili(cluster_centers)


#assegno i cluster ai muri di lista_muri
lista_muri = sg.assegna_cluster_angolare(lista_muri, cluster_centers)


#creo lista di cluster_angolari
cluster_angolari = []
for muro in lista_muri:
	cluster_angolari.append(muro.cluster_angolare)


#---------------CLUSTER SPAZIALI--------------------------------------------------------------------

#setto i cluster spaziali a tutti i muri di lista_muri

lista_muri = sg.set_cluster_spaziali(min_lateral_separation, lista_muri)


#sg.disegna_cluster_angolari(cluster_centers, lista_muri, cluster_angolari)


#creo lista di cluster spaziali
cluster_spaziali = []
for muro in lista_muri:
	cluster_spaziali.append(muro.cluster_spaziale)

sg.disegna_cluster_spaziali(cluster_spaziali, lista_muri)


#------------SETTO XMIN YMIN XMAX YMAX DI LISTA_MURI--------------------------------------------

estremi = sg.trova_estremi(lista_muri)
xmin = estremi[0]
xmax = estremi[1]
ymin = estremi[2]
ymax = estremi[3]
offset = 20
xmin -= offset
xmax += offset
ymin -= offset
ymax += offset


#-------------------CREO EXTENDED_LINES---------------------------------------------------------

extended_lines = rt.crea_extended_lines(cluster_spaziali, lista_muri, xmin, ymin)


#extended_lines hanno punto, cluster_angolare e cluster_spaziale, per disegnarle pero' mi servono 2 punti. Creo lista di segmenti
extended_segments = ext.crea_extended_segments(xmin,xmax,ymin,ymax, extended_lines)


#disegno le extended_lines in nero e la mappa in rosso
ext.disegna_extended_segments(extended_segments, lista_muri)


#-------------CREO GLI EDGES TRAMITE INTERSEZIONI TRA EXTENDED_LINES-------------------------------

punti = []
edges = sg.crea_edges(extended_segments)

#sg.disegna_segmenti(edges)
#sg.disegna_cluster_spaziali(cluster_spaziali, edges)


#----------------------SETTO PESI DEGLI EDGES------------------------------------------------------

edges = sg.set_peso_edges(edges, lista_muri)

#sg.disegna_pesanti(edges, peso_min)


#----------------CREO LE FACCE DAGLI EDGES----------------------------------------------------------

print("creando le facce")

facce = fc.crea_facce(edges)

print("facce create")

#print(len(facce))


#fc.disegna_facce(facce)


#----------------CREO POLIGONO CONTORNO ED ELIMINO FACCE FUORI----------------------------------------------

#creo poligono del contorno
vertici = []
for c1 in contours:
	for c2 in c1:
		vertici.append([float(c2[0][0]),float(c2[0][1])])
dsg.disegna_contorno(vertici,xmin,ymin,xmax,ymax)

contorno = Polygon(vertici)
facce_poly = []
indici = []
for index,f in enumerate(facce):
	punti = []
	for b in f.bordi:
		punti.append([float(b.x1),float(b.y1)])
		punti.append([float(b.x2),float(b.y2)])
	punti = sort_and_deduplicate(punti)
	x = [p[0] for p in punti]
	y = [p[1] for p in punti]
	centroid = (sum(x) / len(punti), sum(y) / len(punti))
	punti.sort(key=algo)
	faccia = Polygon(punti)
	facce_poly.append(faccia)
	if faccia.intersects(contorno)==False:
		#indici.append(index)
		f.set_out(True)
		f.set_parziale(False)
	if (faccia.intersects(contorno)):
		if(faccia.intersection(contorno).area >= faccia.area/3):
			f.set_out(False)
		else:
			f.set_out(True)
			f.set_parziale(False)


a=0
for f in facce:
	for f2 in facce:
		if (f!=f2) and (fc.adiacenti(f,f2)):
			a += 1
	if (a<len(f.bordi)):
		#print("ciao")
		if not (f.out):
			f.set_out(True)
			f.set_parziale(True)
	a = 0

	
a = 1
while(a!=0):
	a = 0
	for f in facce:
		for f2 in facce:
			if (f!=f2) and (f.out==False) and (f2.out==True) and (fc.adiacenti(f,f2)):
				if(fc.edge_comune(f,f2)[0].weight < 0.2):
					f.set_out(True)
					f.set_parziale(True)
					a = 1

	
#for i in sorted(indici, reverse=True):
#	del facce[i]

parziali = []
for i in indici:
	parziali.append(facce[i])


#------------------CREO LE MATRICI L, D, D^-1, ED M = D^-1 * L---------------------------------------

sigma = 0.1
val = 0
matrice_l = mtx.crea_matrice_l(facce, sigma, val)

matrice_d = mtx.crea_matrice_d(matrice_l)

matrice_d_inv = matrice_d.getI()

matrice_m = matrice_d_inv.dot(matrice_l)
matrice_m = mtx.simmetrizza(matrice_m)

X = 1-matrice_m


#----------------DBSCAN PER TROVARE FACCE NELLA STESSA STANZA-----------------------------------------

labels = []
eps = 0.85
min_samples = 1
labels = clustering_dbscan_facce(eps, min_samples, X)

plt.show()


dsg.disegna_dbscan(labels, facce, facce_poly, xmin, ymin, xmax, ymax, edges, contours, True)


plt.show()


#-----------------VORONOI---------------------------------------------------------------

import matplotlib.pyplot as plt
from scipy.spatial import Voronoi, voronoi_plot_2d

from PIL import Image
import numpy as np

#leggo l'immagine e la trasformo in 0 o 255
import cv2
im_gray = cv2.imread(image, cv2.CV_LOAD_IMAGE_GRAYSCALE)
(thresh, im_bw) = cv2.threshold(im_gray, 240, 255, cv2.THRESH_BINARY)
plt.imshow(cv2.cvtColor(im_bw,cv2.COLOR_GRAY2RGB))
plt.show()

#points = punti dei muri
points = []
for y in xrange(0,im_gray.shape[1]):
    for x in xrange(im_gray.shape[0]):
        if im_bw[x, y] == (0):
		points.append([y,x])

points = np.asarray(points)

#distance transform
from scipy import ndimage
a = ndimage.distance_transform_edt(im_bw)
#plt.imshow(a)
#plt.show()

#skeletonization della distance transform
from skimage.morphology import medial_axis
skel, distance = medial_axis(a, return_distance=True)
#plt.plot(points[:,0],points[:,1],'.')
#plt.imshow(skel,cmap='Greys')
#plt.show()

#elimino parte delle imprecisioni della skeletonization
import pymorph as m
b3 = m.thin(skel, m.endpoints('homotopic'), 15)
#plt.plot(points[:,0],points[:,1],'.')
#plt.imshow(b3,cmap='Greys')
#plt.show()

#elimino i pixel isolati
for riga in xrange(b3.shape[0]):
	for col in xrange(b3.shape[1]):
		if b3[riga][col]==True and isolato(b3,riga,col):
			b3[riga][col]=False

plt.plot(points[:,0],points[:,1],'.')
plt.imshow(b3,cmap='Greys')
plt.show()

punti_voronoi = []
#salvo in una lista i punti che fanno parte dello skeleton
for riga in xrange(b3.shape[0]):
	for col in xrange(b3.shape[1]):
		if (b3[riga][col]==True):
			punti_voronoi.append((col,riga))
punti_voronoi = np.asarray(punti_voronoi)
flip_vertici(punti_voronoi,b3.shape[0]-1)

#per ogni punto dello skeleton, vado a vedere se è in prossimità dei bordi di qualche faccia. Se le facce vicine al punto hanno label diverse, vuol dire che in quel punto c'è una porta, o comunque un passaggio diretto.
labels_porte = []
for p in punti_voronoi:
	a = 0
	temp = []
	for index,f in enumerate(facce_poly):
		if (f.boundary).distance(Point(p[0],p[1])) < 1: #se il bordo della faccia dista meno di 1 dal punto.
			a+=1
			if not (labels[index] in temp): #se la label non è già stata aggiunta la aggiungo.
				temp.append(labels[index])
	temp.sort()
	#se la coppia non è già in labels_porte, la aggiungo.
	if not (temp in labels_porte) and (len(temp)>1):
		labels_porte.append(temp)

print(labels_porte)
#plt.plot(np.asarray(punti_voronoi)[:,0],np.asarray(punti_voronoi)[:,1],'.')
#fc.disegna_facce(facce)



#-----------GRAFO---------------------

G = Graph()
for l in set(labels):
	G.add_vertices(1)
	G.vs[len(G.vs)-1]["label"] = l
	
G.add_edges(labels_porte)
layout = G.layout("kk")
plot(G, layout = layout)

