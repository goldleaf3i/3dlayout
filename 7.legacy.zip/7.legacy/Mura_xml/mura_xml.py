from __future__ import division
from matplotlib.path import Path
import matplotlib.patches as patches
import sys
import matplotlib.colors as colors
import numpy as np
import math
import matplotlib.pyplot as plt
import xml.etree.ElementTree as ET
from shapely.geometry import Polygon
from descartes import PolygonPatch
import random

import segmento as sg
import mean_shift as ms
import retta as ret
import extended_segment as ext
import faccia as fc
import matrice as mtx

from itertools import cycle


#-------------------------------FUNZIONI---------------------------------------------


def muri_xml(muri):
	'''
	Trasforma tutti i muri presi dall'xml in oggetti di tipo Segmento, e ritorna una lista di tali segmenti
	''' 
	lista_muri = []
	for muro in muri: #trasformo muri presi da xml in una lista di oggetti Segmento, ognuno avente le coordinate degli estremi
		estremi = muro.findall("./point")
		x1 = float(estremi[0].get('x'))
		y1 = float(estremi[0].get('y'))
		x2 = float(estremi[1].get('x'))
		y2 = float(estremi[1].get('y'))
		#vedo se il muro e' piu corto di una soglia, se e' cosi' allora non lo salvo
		if(sg.lunghezza(x1,y1,x2,y2) >= lunghezza_minima):
			lista_muri.append(sg.Segmento(x1,y1,x2,y2))
	return lista_muri


def disegna(lista):
	ascisse = []
	ordinate = []
	plt.subplot(221)
	plt.title('map from xml')
	for muro in lista:
		ascisse.append(muro.x1)
		ascisse.append(muro.x2)
		ordinate.append(muro.y1)
		ordinate.append(muro.y2)
		plt.plot(ascisse,ordinate, color='k', linewidth=2.0)
		del ascisse[:]
		del ordinate[:]
	#plt.show()
	

def clustering_dbscan(eps, min_samples):
	#af = AffinityPropagation(damping, max_iter, convergence_iter, affinity="precomputed").fit(X)
	af = DBSCAN(eps=0.85, min_samples=1, metric="precomputed").fit(X)
	print("num of clusters = ")
	print len(set(af.labels_))	
	return af.labels_


def disegna_dbscan():
	fig = plt.figure()
	#plt.subplot(224)
	plt.title('dbscan')
	colors = []
	colors.extend(('#800000','#DC143C','#FF0000','#FF7F50','#F08080','#FF4500','#FF8C00','#FFD700','#B8860B','#EEE8AA','#BDB76B','#F0E68C','#808000','#9ACD32','#7CFC00','#ADFF2F','#006400','#90EE90','#8FBC8F','#00FA9A','#20B2AA','#00FFFF','#4682B4','#1E90FF','#000080','#0000FF','#8A2BE2','#4B0082','#800080','#FF00FF','#DB7093','#FFC0CB','#F5DEB3','#8B4513','#808080'))
	ax = fig.add_subplot(111)
	for label, col in zip(set(labels), colors):
		col = random.choice(colors)
		for index,l in enumerate(labels):
			if (l == label):
				f = facce[index]
				f_poly = facce_poligoni[index]
				f_patch = PolygonPatch(f_poly,fc=col,ec='BLACK')
				ax.add_patch(f_patch)
				ax.set_xlim(xmin,xmax)
				ax.set_ylim(ymin,ymax)
				sommax = 0
				sommay = 0
				for b in f.bordi:
					sommax += (b.x1)+(b.x2)
					sommay += (b.y1)+(b.y2)
				xtesto = sommax/(2*len(f.bordi))
				ytesto = sommay/(2*len(f.bordi))
				ax.text(xtesto,ytesto,str(l),fontsize=8)

	ascisse = []
	ordinate = []
	for edge in edges:
		if (edge.weight>0.5):
			ascisse.append(edge.x1)
			ascisse.append(edge.x2)
			ordinate.append(edge.y1)
			ordinate.append(edge.y2)
			plt.plot(ascisse,ordinate, color='k', linewidth=4.0)
			del ascisse[:]
			del ordinate[:]

	plt.show()
	

def uniq(lst):
	'''
elimina i doppioni da una lista
	'''
	last = object()
	for item in lst:
		if item == last:
			continue
		yield item
		last = item


def sort_and_deduplicate(l):
	'''
elimina i doppioni da una lista
	'''
	return list(uniq(sorted(l, reverse=True)))


def algo(p):
	'''
riordina i punti in senso orario
	'''
	return (math.atan2(p[0] - centroid[0], p[1] - centroid[1]) + 2 * math.pi) % (2*math.pi)




#--------------------MAIN-------------------------------------------------------------


#------------CREO LISTA_MURI = MURI XML---------------------------------------------------

tree = ET.parse('/home/matteo/Desktop/Dataset sistemati/'+str(sys.argv[1])+'.xml')
root = tree.getroot()

lunghezza_minima = 3 #30 cm
muri = root.findall(".//space_representation/linesegment[class='WALL']")
lista_muri = muri_xml(muri)


for muro in lista_muri:
	d = sg.inclinazione_radianti(muro.x1, muro.y1, muro.x2, muro.y2)
	if (d < -1.3):
		d += math.pi
	muro.set_direction(d)

#disegna(lista_muri)

#creo lista delle inclinazioni degli edges
directions = []
for muro in lista_muri:
	directions.append(muro.direction)


#-------------------MEAN SHIFT PER TROVARE CLUSTER ANGOLARI---------------------------------------

h = 0.023
offset_minimo = 0.00001
#creo i cluster centers tramite mean shift
cluster_centers = ms.mean_shift(h, offset_minimo, directions)


#ci sono dei cluster angolari che sono causati da pochi e piccoli line_segments, che sono solamente rumore. Questi cluster li elimino dalla lista cluster_centers ed elimino anche i rispettivi segmenti dalla lista_muri.
num_min = 3
lunghezza_min = 10
indici = ms.indici_da_eliminare(num_min, lunghezza_min, cluster_centers, lista_muri)


#ora che ho gli indici di clusters angolari e di muri da eliminare, elimino da lista_muri e cluster_centers, partendo dagli indici piu alti
for i in sorted(indici, reverse=True):
	del lista_muri[i]
	del cluster_centers[i]


#ci son dei cluster che si somigliano ma non combaciano per una differenza infinitesima, e non ho trovato parametri del mean shift che rendano il clustering piu' accurato di cosi', quindi faccio una media normalissima, tanto la differenza e' insignificante.
unito = ms.unisci_cluster_simili(cluster_centers)
while(unito):
	unito = ms.unisci_cluster_simili(cluster_centers)


#assegno i cluster ai muri di lista_muri
lista_muri = sg.assegna_cluster_angolare(lista_muri, cluster_centers)


#creo lista di cluster_angolari
cluster_angolari = []
for muro in lista_muri:
	cluster_angolari.append(muro.cluster_angolare)



#---------------CLUSTER SPAZIALI--------------------------------------------------------------------

#setto i cluster spaziali a tutti i muri di lista_muri
min_lateral_separation = 10
lista_muri = sg.set_cluster_spaziali(min_lateral_separation, lista_muri)


#sg.disegna_cluster_angolari(cluster_centers, lista_muri, cluster_angolari)


#creo lista di cluster spaziali
cluster_spaziali = []
for muro in lista_muri:
	cluster_spaziali.append(muro.cluster_spaziale)


#sg.disegna_cluster_spaziali(cluster_spaziali, lista_muri)



#------------SETTO XMIN YMIN XMAX YMAX DI LISTA_MURI--------------------------------------------

estremi = sg.trova_estremi(lista_muri)
xmin = estremi[0]
xmax = estremi[1]
ymin = estremi[2]
ymax = estremi[3]
offset = 10
xmin -= offset
xmax += offset
ymin -= offset
ymax += offset



#-------------------CREO EXTENDED_LINES---------------------------------------------------------

extended_lines = ret.crea_extended_lines(cluster_spaziali, lista_muri, xmin, ymin)


#extended_lines hanno punto, cluster_angolare e cluster_spaziale, per disegnarle pero' mi servono 2 punti. Creo lista di segmenti
extended_segments = ext.crea_extended_segments(xmin,xmax,ymin,ymax, extended_lines)


#disegno le extended_lines in nero e la mappa in rosso
ext.disegna_extended_segments(extended_segments, lista_muri)



#-------------CREO GLI EDGES TRAMITE INTERSEZIONI TRA EXTENDED_LINES-------------------------------

punti = []
edges = sg.crea_edges(extended_segments)

#sg.disegna_segmenti(edges)
#sg.disegna_cluster_spaziali(cluster_spaziali, edges)



#----------------------SETTO PESI DEGLI EDGES------------------------------------------------------

edges = sg.set_peso_edges(edges, lista_muri)



#----------------CREO LE FACCE DAGLI EDGES----------------------------------------------------------


facce = fc.crea_facce(edges)


#print(len(facce))


#fc.disegna_facce(facce)



#-----------------CREO I POLIGONI DELLE FACCE--------------------------------------------------------

#creo i poligoni delle facce.
indici = []
facce_poligoni = []
for index,f in enumerate(facce):
	punti = []
	for b in f.bordi:
		punti.append([float(b.x1),float(b.y1)])
		punti.append([float(b.x2),float(b.y2)])
	#elimino i punti ripetuti
	punti = sort_and_deduplicate(punti)
	x = [p[0] for p in punti]
	y = [p[1] for p in punti]
	centroid = (sum(x) / len(punti), sum(y) / len(punti))
	#ordino i punti in senso orario	
	punti.sort(key=algo)
	faccia = Polygon(punti)
	facce_poligoni.append(faccia)



#------------------CREO LE MATRICI L, D, D^-1, ED M = D^-1 * L---------------------------------------

sigma = 0.1
val = 0
matrice_l = mtx.crea_matrice_l(facce, sigma, val)

matrice_d = mtx.crea_matrice_d(matrice_l)

matrice_d_inv = matrice_d.getI()

matrice_m = matrice_d_inv.dot(matrice_l)
matrice_m = mtx.simmetrizza(matrice_m)

X = 1-matrice_m



#----------------DBSCAN PER TROVARE FACCE NELLA STESSA STANZA-----------------------------------------

from sklearn.cluster import DBSCAN

labels = []
eps = 0.85
min_samples = 1
labels = clustering_dbscan(eps, min_samples)



disegna_dbscan()

plt.show()

				

